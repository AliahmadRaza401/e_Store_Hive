import 'package:e_store/components/buttoncart.dart';
import 'package:e_store/screens/cardwidget.dart';
import 'package:e_store/widgets/giftcardswidget.dart';
import 'package:e_store/widgets/header.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _active = false;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Stack(
            children: <Widget>[
              SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    Header(),
                    GiftCardsWidget(),
                    SizedBox(height: 10),
                    CartButton(
                      iconData: Icons.add,
                      color: Color(0xFF809EDC), //lighter
                      label: "ADD TO CART",
                      onTap: () {
                        setState(() {
                          _active = true;
                        });
                      },
                    )
                  ],
                ),
              ),
              CardWidget(
                active: _active,
                onTap: () {
                  setState(() {
                    _active = false;
                  });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
