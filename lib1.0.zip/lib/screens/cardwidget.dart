import 'package:e_store/components/buttoncart.dart';
import 'package:e_store/components/buttonqty.dart';
import 'package:e_store/components/sizebutton.dart';
import 'package:flutter/material.dart';

class CardWidget extends StatefulWidget {
  final bool? active;
  final VoidCallback? onTap;

  CardWidget({Key? key, this.active, this.onTap}) : super(key: key);

  @override
  _CardWidgetState createState() => _CardWidgetState();
}

class _CardWidgetState extends State<CardWidget> {
  int _quantity = 1;
  void _add() {
    setState(() {
      _quantity += 1;
    });
  }

  void _remove() {
    setState(() {
      if (_quantity > 1) {
        _quantity -= 1;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedPositioned(
      duration: Duration(milliseconds: 500),
      curve: Curves.decelerate,
      bottom: widget.active! ? 5 : -600,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        height: MediaQuery.of(context).size.height * 0.70,
        width: MediaQuery.of(context).size.width * 0.95,
        decoration: BoxDecoration(
            color: Color.fromARGB(255, 159, 183, 232),
            borderRadius: BorderRadius.all(Radius.circular(30))),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Text("iTunes Gift Card",
                  style: TextStyle(fontSize: 36, color: Colors.white)),
              SizedBox(height: 40),
              productSize(),
              SizedBox(height: 40),
              _Quantity(add: _add, remove: _remove, quantity: _quantity),
              SizedBox(height: 30),
              CartButton(
                color: Colors.white,
                label: "PAY",
                onTap: widget.onTap,
              )
            ],
          ),
        ),
      ),
    );
  }
}

Widget productSize() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Text("Funds", style: TextStyle(fontSize: 30, color: Colors.white)),
      SizedBox(height: 14),
      Row(
        children: <Widget>[
          SizeButton(
            amount: "\$100",
            active: false,
          ),
          SizeButton(
            amount: "\$50",
            active: true,
          ),
          SizeButton(
            amount: "\$100",
            active: false,
          )
        ],
      )
    ],
  );
}

Widget _Quantity({VoidCallback? add, VoidCallback? remove, int? quantity}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Text("Qty", style: TextStyle(fontSize: 24, color: Colors.white)),
      SizedBox(height: 14),
      Row(
        children: <Widget>[
          QtyButton(
            iconData: Icons.add,
            onTap: add,
          ),
          _quantityBox(quantity!),
          QtyButton(
            iconData: Icons.remove,
            onTap: remove,
          ),
        ],
      )
    ],
  );
}

Widget _quantityBox(int quantity) {
  return Container(
    height: 70,
    width: 180,
    alignment: Alignment.center,
    margin: EdgeInsets.only(right: 10),
    decoration: BoxDecoration(
        color: Colors.transparent,
        border: Border.all(color: Colors.white, width: 1.5),
        borderRadius: BorderRadius.all(Radius.circular(10))),
    child: Text(quantity.toString(),
        style: TextStyle(
            fontSize: 22, color: Colors.white, fontWeight: FontWeight.bold)),
  );
}
