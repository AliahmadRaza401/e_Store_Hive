// import 'package:hive/hive.dart';

// part 'cart_model.g.dart';

